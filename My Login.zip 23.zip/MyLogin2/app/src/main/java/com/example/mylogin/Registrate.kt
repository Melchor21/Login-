package com.example.mylogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Registrate : AppCompatAct      setContentView(R.layout.activity_registrate)
ivity() {
    override fun onCreate(savedInstanceState: Bundle?)
        super.onCreate(savedInstanceState)
    }
}